
import React, { useState, useRef } from "react";
import { FlatList, Dimensions } from "react-native";
import Player from "../components/Player/Player";

const { height } = Dimensions.get("window");

const data = [
  { id: "1", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
  { id: "2", videoUrl: "https://www.w3schools.com/html/movie.mp4" }
];

export default function HomeScreen() {
  const [active, setActive] = useState(0);

  const onViewableItemsChanged = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      setActive(viewableItems[0].index);
    }
  });

  return (
    <FlatList
      data={data}
      pagingEnabled
      keyExtractor={(item) => item.id}
      renderItem={({ item, index }) => (
        <Player source={item.videoUrl} isActive={index === active} />
      )}
      onViewableItemsChanged={onViewableItemsChanged.current}
    />
  );
}
