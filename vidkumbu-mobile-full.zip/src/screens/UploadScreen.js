
import React, { useState } from "react";
import { View, Button } from "react-native";
import * as ImagePicker from "expo-image-picker";

export default function UploadScreen() {
  const [video, setVideo] = useState(null);

  const pick = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos
    });
    if (!res.canceled) setVideo(res.assets[0].uri);
  };

  return (
    <View style={{ marginTop: 50 }}>
      <Button title="Escolher vídeo" onPress={pick} />
    </View>
  );
}
