
import React, { useRef, useEffect } from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import { Video } from "expo-av";

const { height } = Dimensions.get("window");

export default function Player({ source, isActive }) {
  const ref = useRef(null);

  useEffect(() => {
    if (isActive) ref.current?.playAsync();
    else ref.current?.pauseAsync();
  }, [isActive]);

  return (
    <View style={styles.container}>
      <Video
        ref={ref}
        source={{ uri: source }}
        style={styles.video}
        resizeMode="cover"
        isLooping
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { height, backgroundColor: "#000" },
  video: { width: "100%", height: "100%" }
});
